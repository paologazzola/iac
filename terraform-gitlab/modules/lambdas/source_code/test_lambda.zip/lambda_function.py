
def lambda_handler(event, context):
    
    return {
        'status': 200,
        'message': 'test'
    }
